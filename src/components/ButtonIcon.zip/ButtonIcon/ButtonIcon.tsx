import { MainButtonIcon, SpanIcon } from "./styles";
import { ButtonProps } from "./types";

function ButtonIcon(props: ButtonProps) {
	const {
		size = 24,
		icon = "SEND",
		type = "button",
		onClick,
		disabled = false,
		...rest
	} = props;

	return (
		<MainButtonIcon
			size={size}
			type={type}
			onClick={onClick}
			disabled={disabled}
			{...rest}
		>
			<SpanIcon translate="no" className="material-symbols-outlined">
				{icon}
			</SpanIcon>
		</MainButtonIcon>
	);
}
export default ButtonIcon;
